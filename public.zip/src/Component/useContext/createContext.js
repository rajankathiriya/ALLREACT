const { createContext } = require("react")

const Language = createContext('en');

export default Language