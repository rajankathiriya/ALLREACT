import React from 'react';
import Child4 from './Child4';

const Child3 = () => {
    return (
        <div>
            <Child4 />
        </div>
    );
}

export default Child3;
