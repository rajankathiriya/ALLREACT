import React, { createContext } from 'react'

export default function Child4() {
    createContext();
    return (
        <div>

        </div>
    )
}
