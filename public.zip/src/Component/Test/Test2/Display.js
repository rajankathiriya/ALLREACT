import React from 'react'

export default function Display(data) {
    return (
        <div >
            <img src={data.imagess} />
        </div>
    )
}
