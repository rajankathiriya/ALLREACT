import React from 'react'

export default function Footer() {
    return (
        <div className=''>

            <div className="container-fluid fixed-bottom bg-dark text-white p-3">
                <div className="row">
                    <div className="col-sm-3">
                        <h4>Name</h4>
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                    </div>
                    <div className="col-sm-3">
                        <h4>Name</h4>
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                    </div>
                    <div className="col-sm-3">
                        <h4>Name</h4>
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                    </div>
                    <div className="col-sm-3">
                        <h4>Name</h4>
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                        <span>Link-1</span><br />
                    </div>
                </div>
            </div>

        </div>
    )
}
