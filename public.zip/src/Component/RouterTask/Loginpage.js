import React from 'react'

export default function Loginpage() {
    return (
        <div>Loginpage</div>
    )
}
