import React from 'react'
import image from './Image/404.gif'
export default function Error() {
    return (

        <div className='m-5'>
            <img src={image} alt="" style={{ width: "500px" }} className='mx-auto' />

        </div>
    )
}
