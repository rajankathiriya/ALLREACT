import React from 'react'

export default function Homew3() {
    return (
        <div>
            <h1 className='text-center'>This is home Page</h1>
        </div>
    )
}
