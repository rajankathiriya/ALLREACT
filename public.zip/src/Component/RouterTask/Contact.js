import React from 'react'
import imgcon from './Image/Contact.gif'

export default function Contact() {
    return (
        <div>
            <div>
                <img src={imgcon} alt="" className='w-100 p-2' />
            </div>
        </div>
    )
}
