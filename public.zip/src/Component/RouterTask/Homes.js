import React from 'react'
import imagehome from './Image/Home.gif'

export default function Home() {
    return (
        <div>
            <img src={imagehome} alt="" className='w-100 p-2' />
        </div>
    )
}
