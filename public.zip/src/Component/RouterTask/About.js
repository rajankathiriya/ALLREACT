import React from 'react'

export default function About() {
    return (
        <div>
            this is about data

        </div>
    )
}
