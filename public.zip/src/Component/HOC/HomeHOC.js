import React from 'react'


export default function HomeHOC() {
    return (
        <div className='m-5'>
            <h2 className="text-center">Welcome Home Page !</h2>

        </div>
    )
}
