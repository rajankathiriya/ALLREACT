// export const first = (payload) => ({
//   type: second,
//   payload
// })

export const Increment = () => ({
    type: "Increment",
});
export const Decrement = () => ({
    type: "Decrement",
});
export const Multiplication = () => ({
    type: "Multiplication",
});
export const Division = () => ({
    type: "Division",
});



