import React from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { Asyncthunk, Minus, Plus } from './Action/Action';
const MainCounter = () => {
    const Data = useSelector(y => y.counter)

    const myDis = useDispatch()

    const Myinc1 = () => {
        myDis(Plus())
    }

    const Myinc2 = () => {
        myDis(Minus())
    }

    const Myinc3 = () => {
        myDis(Asyncthunk(4))
    }
    return (
        <div>
            {Data}
            <button onClick={Myinc1}>Inc+</button>
            <button onClick={Myinc2}>Dec-</button>
            <button onClick={Myinc3}>Dec---</button>
        </div>
    );
}

export default MainCounter;
