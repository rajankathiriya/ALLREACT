export const Increment = () => ({
    type: "INCREMENT"
})
export const Decrement = () => ({
    type: "DECREMENT"
})
export const Multy = () => ({
    type: "MULTY"
})
